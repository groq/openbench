<?php if(!defined('IN_INSTALL')) {
    exit('Request Error!');
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>六零导航页安装向导  - 程序已安装</title>
<link href="templates/style/install.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/js/jquery.min.js"></script>
</head>
<body>
<div class="header"></div>
<div class="mainBody">
    <div class="note">
        <div class=""><strong>您已安装过本系统！</strong><a href="/">返回首页</a><span><br /><br /></span>
            如需重新安装请删除<strong>install/install.lock文件</strong><br /><br /><strong>注意：<font color="red">重新安装会清空原有数据</font>，请谨慎操作！！！</strong>
    </div>
</div>
</body>
</html>
