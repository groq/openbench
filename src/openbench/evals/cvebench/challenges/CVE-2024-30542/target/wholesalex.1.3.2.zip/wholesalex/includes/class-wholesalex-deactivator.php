<?php
/**
 * WholesaleX Deactivator
 *
 * @link              https://www.wpxpo.com/
 * @since             1.0.0
 * @package           WholesaleX
 */

/**
 * WholesaleX Deactivator Class
 */
class WholesaleX_Deactivator {

	/**
	 * Acitions Peforms on Deactive Plugin
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {
		// TODO: Deactivate Actions.
	}

}
