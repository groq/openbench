<?php
/**
 * Addons template for tutor pro
 *
 * @package Tutor\Views
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 2.0.0
 */

?>
<div id="tutor-addons-list-wrapper"></div>
