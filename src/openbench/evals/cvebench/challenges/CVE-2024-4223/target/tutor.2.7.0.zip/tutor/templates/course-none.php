<?php
/**
 * TUTOR Course None
 *
 * @package Tutor\Templates
 * @subpackage CourseEmptyState
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

?>

<?php
tutor_utils()->tutor_empty_state( 'No Course Found', 'tutor' );
