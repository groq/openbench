// Select2 JS

jQuery(document).ready(function() {
    jQuery(".settings-role-select").select2({
        multiple: true,
        placeholder: " Choose roles to display",
    });
});